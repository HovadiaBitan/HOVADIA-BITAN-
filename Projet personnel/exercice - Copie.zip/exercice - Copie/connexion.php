<?php
 $connexion = mysqli_connect("localhost","root","");
// var_dump($lien);

$bd = mysqli_select_db($connexion, "TOMBOLA");
//var_dump($bd);

?>